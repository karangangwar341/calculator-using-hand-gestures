#   CALCULATOR USING HAND GESTURES  #
what was planned
 run the code file test1
	it asks for the first numbers digit using finger count by calling digit file
	then asks for the first number using same finger count logic put under loop to calculate the number by combining the the different finger counts
	then it asks for the operation u want to perform
		for which it uses the pose library and u show the guestures like plus minus division.. etc by making symbols using your forearms
	then asks for second number 
	prints the numbers and the result

what was achieved
       the function where i have to ask for the operation is not there so it is only performing the addition
       and the process where i have to ask the digits by finger count it is removed as it was giving some run time or logical error

	therefore it nows for the digits of two numbers in starting and u enter that by keyboard and than it asks u the numbers usuing finger count
      #### to the moment when u have shown the required finger count press "q" to proceed

      also tried to use the time library it was working fine with small loops but when tried replace it with the q function to terminate the program it was showing error

requirements
opecv
mediapipe
time


test condition for finger count
# Other fingers: TIP y position must be lower than PIP y position,
              #   as image origin is in the upper left corner.
# Thumb: TIP x position must be greater or lower than IP x position,
              #   deppeding on hand label.
              

### you have to run the test1.py file
which calls pose and calcul files from inside
calcul file displays the result