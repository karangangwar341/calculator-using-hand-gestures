import pose
import calcul
x = int(input("enter the number of digits in the first number"))
y = int(input("enter the number of digits in the second number"))
num1 = int(pose.inpt(x))
num2 = int(pose.inpt(y))
res =  num1+num2
calcul.outpt(num1,num2,res)
